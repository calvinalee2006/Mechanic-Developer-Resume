The Dasmoto's paint shop project from codecademy. 
